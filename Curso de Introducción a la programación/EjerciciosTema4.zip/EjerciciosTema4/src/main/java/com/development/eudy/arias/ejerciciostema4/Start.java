/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.development.eudy.arias.ejerciciostema4;
import Services.*;
/**
 *
 * @author developer
 */
public class Start {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        SentenciasControl.funcIf();
        SentenciasControl.funcWhile();
        SentenciasControl.funcDoWhile();
        SentenciasControl.funcFor();        
        SentenciasControl.funcSwitch();
    }
    
}
