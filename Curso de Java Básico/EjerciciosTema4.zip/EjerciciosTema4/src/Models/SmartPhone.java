package Models;

public class SmartPhone extends SmartDevice{
    public SmartPhone() {
    }

    public SmartPhone(String tipo, String marca, String modelo) {
        super(tipo, marca, modelo);
    }
}
