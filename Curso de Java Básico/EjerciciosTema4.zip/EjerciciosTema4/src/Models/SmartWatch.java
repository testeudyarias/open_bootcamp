package Models;

public class SmartWatch extends SmartDevice{
    public SmartWatch() {
    }

    public SmartWatch(String tipo, String marca, String modelo) {
        super(tipo, marca, modelo);
    }
}
